/*
 *  This file does not require debugging.
 */
public class Bird extends Pet {

    public Bird(String name)
    {
        super(name);
    }

    public void saySomething(){}

}
