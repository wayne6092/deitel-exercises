// This file will require debugging.  
// If we want all Pets to speak, what
// do you need to do in this file?

public abstract class Pet {

    String name;

    public Pet(String name){
        this.name = name;
    }
}
