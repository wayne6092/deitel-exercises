/*
 * This file requires debugging.
 */
public class Speak {
    public void saySomething();
}
