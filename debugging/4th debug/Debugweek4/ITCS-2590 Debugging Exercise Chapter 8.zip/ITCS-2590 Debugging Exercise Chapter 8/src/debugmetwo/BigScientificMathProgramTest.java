package debugmetwo;

/**
 *  Run this program to validate your output.
 * 
 */
public class BigScientificMathProgramTest {
    public static void main(String[] args) {
        BigScientificMathProgram bsmp = new BigScientificMathProgram();
        bsmp.generateSomeBigScientificCalcuation();
    }
}
